// Mạch giám sát nhiệt độ: máy trạng thái 3 mức + trễ (hysteresis) + ghi min/max.
// Nhiệt độ vào theo đơn vị 0.1 °C (352 = 35.2 °C).
module temp_monitor #(
    parameter WARN  = 300,   // 30.0 °C -> Chú ý
    parameter ALARM = 350,   // 35.0 °C -> Cảnh báo (trùng ngưỡng trong main.cpp)
    parameter HYST  = 10     // 1.0 °C trễ khi hạ mức, tránh nhấp nháy
)(
    input             clk,
    input             rst_n,
    input             valid,        // =1 khi có mẫu mới
    input      [11:0] temp_x10,
    output reg [1:0]  state,        // 0 bình thường, 1 chú ý, 2 cảnh báo
    output            led_green,
    output            led_yellow,
    output            led_red,
    output reg [11:0] t_max,
    output reg [11:0] t_min
);
    localparam NORMAL = 2'd0, WARNING = 2'd1, ALARMING = 2'd2;

    assign led_green  = (state == NORMAL);
    assign led_yellow = (state == WARNING);
    assign led_red    = (state == ALARMING);

    always @(posedge clk or negedge rst_n) begin
        if (!rst_n) begin
            state <= NORMAL;
            t_max <= 12'd0;
            t_min <= 12'hFFF;
        end else if (valid) begin
            if (temp_x10 > t_max) t_max <= temp_x10;
            if (temp_x10 < t_min) t_min <= temp_x10;
            case (state)
                NORMAL:   if (temp_x10 >= ALARM)      state <= ALARMING;
                          else if (temp_x10 >= WARN)  state <= WARNING;
                WARNING:  if (temp_x10 >= ALARM)      state <= ALARMING;
                          else if (temp_x10 < WARN - HYST) state <= NORMAL;
                ALARMING: if (temp_x10 < ALARM - HYST)
                              state <= (temp_x10 >= WARN) ? WARNING : NORMAL;
                default:  state <= NORMAL;
            endcase
        end
    end
endmodule
