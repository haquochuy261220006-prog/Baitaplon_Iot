`timescale 1ns/1ps
// Testbench: đọc dãy nhiệt độ từ temps.hex (mỗi dòng 1 mẫu, hex, đơn vị 0.1 °C)
module tb_temp_monitor;
    reg clk = 0, rst_n = 0, valid = 0;
    reg  [11:0] temp = 0;
    wire [1:0]  state;
    wire        g, y, r;
    wire [11:0] tmax, tmin;
    reg  [11:0] mem [0:1023];
    integer i;

    temp_monitor #(.WARN(300), .ALARM(350), .HYST(10)) dut (
        .clk(clk), .rst_n(rst_n), .valid(valid), .temp_x10(temp),
        .state(state), .led_green(g), .led_yellow(y), .led_red(r),
        .t_max(tmax), .t_min(tmin));

    always #5 clk = ~clk;

    initial begin
        $readmemh("temps.hex", mem);
        $dumpfile("wave.vcd");
        $dumpvars(0, tb_temp_monitor);
        #22 rst_n = 1;
        i = 0;
        while (i < 1024 && mem[i] !== 12'hxxx) begin
            @(negedge clk); temp = mem[i]; valid = 1;
            @(posedge clk); #1;
            $display("OUT %0d %0d %0d", i, temp, state);
            i = i + 1;
        end
        valid = 0; #20;
        $display("DONE tmax=%0d tmin=%0d", tmax, tmin);
        $finish;
    end
endmodule
