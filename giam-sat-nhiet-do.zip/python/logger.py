"""Nhận dữ liệu từ ESP32 (Wokwi) qua MQTT, ghi CSV, và xuất temps.hex cho Verilog.
Chạy:  python logger.py        (Ctrl+C để dừng)
       python logger.py 80     (tự dừng sau 80 giây)
Khi dừng sẽ xuất file hex.
"""
import csv, json, pathlib, sys, time
from datetime import datetime
import paho.mqtt.client as mqtt

TOPIC = "tn/nhietdo/sv319528/data"   # phải giống main.cpp và index.html
ROOT = pathlib.Path(__file__).resolve().parent.parent
CSV_PATH = ROOT / "python" / "data" / "log.csv"
HEX_PATH = ROOT / "verilog" / "temps.hex"

temps = []  # nhiệt độ x10 (số nguyên) để Verilog xử lý

def on_connect(client, userdata, flags, reason_code, properties):
    print("Đã kết nối broker, đang nghe topic:", TOPIC)
    client.subscribe(TOPIC)

def on_message(client, userdata, msg):
    try:
        d = json.loads(msg.payload)
    except ValueError:
        return
    now = datetime.now().strftime("%H:%M:%S")
    print(f"{now}  {d['temp']:.1f} °C  {d['hum']:.0f} %  {'CẢNH BÁO' if d['alarm'] else 'ok'}")
    with open(CSV_PATH, "a", newline="") as f:
        csv.writer(f).writerow([now, d["temp"], d["hum"], int(d["alarm"])])
    temps.append(max(0, round(d["temp"] * 10)))

CSV_PATH.parent.mkdir(exist_ok=True)
if not CSV_PATH.exists():
    CSV_PATH.write_text("time,temp,hum,alarm\n")

client = mqtt.Client(mqtt.CallbackAPIVersion.VERSION2)
client.on_connect, client.on_message = on_connect, on_message
client.connect("broker.hivemq.com", 1883)
duration = int(sys.argv[1]) if len(sys.argv) > 1 else None
client.loop_start()
try:
    t0 = time.time()
    while duration is None or time.time() - t0 < duration:
        time.sleep(0.5)
except KeyboardInterrupt:
    pass
finally:
    client.loop_stop()
    if temps:
        HEX_PATH.write_text("".join(f"{v:03X}\n" for v in temps[-1024:]))
        print(f"\nĐã ghi {len(temps)} mẫu vào {HEX_PATH}")
