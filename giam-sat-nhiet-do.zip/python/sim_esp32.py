"""Giả lập ESP32 + DHT22 bằng Python (dùng khi không chạy Wokwi).
Nhiệt độ dao động 22-38 °C nên đi qua cả 3 mức: bình thường, chú ý, cảnh báo."""
import json, math, random, time
import paho.mqtt.client as mqtt

TOPIC = "tn/nhietdo/sv319528/data"

client = mqtt.Client(mqtt.CallbackAPIVersion.VERSION2)
client.connect("broker.hivemq.com", 1883)
client.loop_start()
print("Dang gia lap ESP32, gui du lieu toi", TOPIC)
n = 0
while True:
    t = round(30 + 8 * math.sin(n / 6) + random.uniform(-0.3, 0.3), 1)
    h = round(60 + 10 * math.cos(n / 6), 1)
    msg = json.dumps({"temp": t, "hum": h, "alarm": t > 35})
    client.publish(TOPIC, msg)
    print(msg)
    n += 1
    time.sleep(2)
