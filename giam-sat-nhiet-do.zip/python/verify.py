"""Chạy mô phỏng Verilog (Icarus) và đối chiếu với mô hình Python.
Chạy:  python verify.py
"""
import pathlib, subprocess, sys

V = pathlib.Path(__file__).resolve().parent.parent / "verilog"
WARN, ALARM, HYST = 300, 350, 10
NAMES = ["Bình thường", "Chú ý", "Cảnh báo"]

def model(temps):
    s, out = 0, []
    for t in temps:
        if s == 0:
            s = 2 if t >= ALARM else 1 if t >= WARN else 0
        elif s == 1:
            s = 2 if t >= ALARM else 0 if t < WARN - HYST else 1
        elif t < ALARM - HYST:
            s = 1 if t >= WARN else 0
        out.append(s)
    return out

temps = [int(l, 16) for l in (V / "temps.hex").read_text().split()]
try:
    subprocess.run(["iverilog", "-o", "sim.out", "tb_temp_monitor.v", "temp_monitor.v"], cwd=V, check=True)
    res = subprocess.run(["vvp", "sim.out"], cwd=V, capture_output=True, text=True, check=True)
except FileNotFoundError:
    sys.exit("Chưa cài Icarus Verilog (iverilog). Cài rồi chạy lại.")

hw = [int(l.split()[3]) for l in res.stdout.splitlines() if l.startswith("OUT")]
sw = model(temps)
print(f"{'#':>3} {'°C':>6}  {'Verilog':<12} {'Python':<12}")
for i, (t, a, b) in enumerate(zip(temps, hw, sw)):
    print(f"{i:>3} {t/10:>6.1f}  {NAMES[a]:<12} {NAMES[b]:<12}{'' if a == b else '  <-- LỆCH'}")
print("\nKẾT QUẢ:", "PASS, Verilog khớp mô hình Python" if hw == sw else "FAIL")
print(res.stdout.splitlines()[-1] if res.stdout else "")
