"""Tự tạo topic riêng và điền vào mọi file (thay cho việc sửa CHANGE_ME bằng tay)."""
import pathlib, random

ROOT = pathlib.Path(__file__).resolve().parent.parent
FILES = ["src/main.cpp", "web/index.html", "python/logger.py", "python/sim_esp32.py"]
topic_id = "sv" + str(random.randint(100000, 999999))
changed = False
for f in FILES:
    p = ROOT / f
    s = p.read_text(encoding="utf-8")
    if "CHANGE_ME" in s:
        p.write_text(s.replace("CHANGE_ME", topic_id), encoding="utf-8")
        changed = True
print(f"Da tao topic rieng: tn/nhietdo/{topic_id}/data" if changed else "Topic da duoc cai dat san.")
