@echo off
cd /d "%~dp0"
where python >nul 2>nul && (set PY=python) || (set PY=py)

echo === [1/4] Cai thu vien Python...
%PY% -m pip install -q -r python\requirements.txt
echo === [2/4] Tao topic rieng...
%PY% python\setup.py
echo.
echo   [1] Demo nhanh: gia lap ESP32 bang Python (khong can Wokwi)
echo   [2] Dung Wokwi that (hay bat Wokwi trong VS Code truoc)
set /p C=Chon 1 hoac 2 roi Enter: 

if "%C%"=="1" start "SIM" %PY% python\sim_esp32.py
echo === [3/4] Mo web va ghi log 80 giay...
start "" web\index.html
%PY% python\logger.py 80
echo === [4/4] Chay mo phong Verilog va doi chieu voi Python...
%PY% python\verify.py
taskkill /FI "WINDOWTITLE eq SIM*" /F >nul 2>nul
echo.
pause
