#include <Arduino.h>
#include <WiFi.h>
#include <PubSubClient.h>
#include <DHT.h>

// ---- Cấu hình ----
#define DHT_PIN   15
#define LED_RED   2      // sáng khi quá ngưỡng
#define LED_GREEN 4      // sáng khi bình thường
const float NGUONG = 35.0;                       // °C
const char* MQTT_HOST = "broker.hivemq.com";
const char* TOPIC = "tn/nhietdo/sv319528/data"; // phải giống file web/index.html

DHT dht(DHT_PIN, DHT22);
WiFiClient net;
PubSubClient mqtt(net);

// Kết nối MQTT không chặn chương trình: đèn vẫn chạy khi chưa có mạng
void ketNoiMang() {
  static bool daBaoWifi = false;
  static unsigned long lanThu = 0;
  if (WiFi.status() != WL_CONNECTED) { daBaoWifi = false; return; }
  if (!daBaoWifi) { Serial.println("WiFi OK"); daBaoWifi = true; }
  if (!mqtt.connected() && millis() - lanThu > 5000) {
    lanThu = millis();
    String id = "esp32-" + String(random(0xffff), HEX);
    if (mqtt.connect(id.c_str())) Serial.println("MQTT OK");
    else Serial.println("MQTT loi, se thu lai sau 5 giay");
  }
}

void setup() {
  Serial.begin(115200);
  pinMode(LED_RED, OUTPUT);
  pinMode(LED_GREEN, OUTPUT);
  dht.begin();
  WiFi.begin("Wokwi-GUEST", "", 6);
  mqtt.setServer(MQTT_HOST, 1883);
  Serial.println("Khoi dong...");
}

void loop() {
  ketNoiMang();
  mqtt.loop();

  static unsigned long last = 0;
  if (millis() - last < 2000) return;
  last = millis();

  float t = dht.readTemperature();
  float h = dht.readHumidity();
  if (isnan(t) || isnan(h)) { Serial.println("Loi doc DHT22"); return; }

  bool canhBao = t > NGUONG;
  digitalWrite(LED_RED, canhBao);      // đèn điều khiển trước, không phụ thuộc mạng
  digitalWrite(LED_GREEN, !canhBao);

  char msg[80];
  snprintf(msg, sizeof(msg), "{\"temp\":%.1f,\"hum\":%.1f,\"alarm\":%s}", t, h, canhBao ? "true" : "false");
  if (mqtt.connected()) mqtt.publish(TOPIC, msg);
  Serial.println(msg);
}
